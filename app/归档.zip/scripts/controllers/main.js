define([
    'jquery',
    'angular'
  ], function ($, angular) {
    'use strict';
    angular.module('kaoshiApp.controllers.MainCtrl', []).
      controller('MainCtrl', function ($rootScope, $scope, $http) {

    });
  }
);
